package com.cg.ems.exception;

public class EmployeeException extends Exception{
    String msg;
	public EmployeeException(String msg)
	{
		super (msg);

	}
	public EmployeeException(String msg,Throwable cause,Error code)
	{
		//super (msg,cause,code);

	}
	
}
