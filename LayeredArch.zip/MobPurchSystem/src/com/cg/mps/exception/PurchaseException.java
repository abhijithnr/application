package com.cg.mps.exception;

public class PurchaseException extends Exception{
	String msg;
	public PurchaseException(String msg)
	{
		super (msg);

	}
	public PurchaseException(String msg,Throwable cause,Error code)
	{
		//super (msg,cause,code);

	}

}
