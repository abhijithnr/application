package com.cg.mps.junit;

import java.util.ArrayList;

import junit.framework.Assert;

import org.junit.Test;

import com.cg.mps.dao.CustDaoImpl;
import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.PurchaseException;
import com.cg.mps.service.PurhcaseServiceImpl;

public class TestMobilePurchase {
	
CustDaoImpl ms=new CustDaoImpl();
@Test
public void testInsert() throws PurchaseException
{
	Customer mb=new Customer(4444,"Sam","sam@gmail.com","9874561230",1002);
	Assert.assertEquals(1, ms.addCust(mb));
}
@Test
public void testInsert1() throws PurchaseException
{
	Assert.assertNotNull(ms);
}
@Test
public void testSearch() throws PurchaseException
{
	PurhcaseServiceImpl ps1test3=new PurhcaseServiceImpl();
	ArrayList<Mobile> arr=new ArrayList();
	 arr=ps1test3.searchMob(10000,50000);
	Assert.assertEquals(false, arr.isEmpty());
	
}
@Test
public void Search1() throws PurchaseException
{

	PurhcaseServiceImpl ps1test4=new PurhcaseServiceImpl();
	ArrayList<Mobile> arr=new ArrayList();
	 arr=ps1test4.searchMob(50000,10000);
	Assert.assertEquals(true, arr.isEmpty());
}}
