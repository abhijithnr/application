package com.cg.mps.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mps.dao.CustDao;
import com.cg.mps.dao.CustDaoImpl;
import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.PurchaseException;

public class PurhcaseServiceImpl implements PurchaseService {
	CustDao custDao=null;
	public PurhcaseServiceImpl()
	{
		custDao=new CustDaoImpl();
	}

	@Override
	public ArrayList<Customer> getAllCust() throws PurchaseException {
		// TODO Auto-generated method stub
		return custDao.getAllCust();
	}

	

	@Override
	public int addCust(Customer cs) throws PurchaseException {
		// TODO Auto-generated method stub
		return custDao.addCust(cs);
	}

	@Override
	public int updateMob(int mid) throws PurchaseException {
		// TODO Auto-generated method stub
		return custDao.updateMob(mid);
	}

	@Override
	public int deleteMob(int mid) throws PurchaseException {
		// TODO Auto-generated method stub
		return custDao.deleteMob(mid);
	}

	@Override
	public boolean validateCustomername(String cName) throws PurchaseException {
		// TODO Auto-generated method stub
		if (cName.length()<=20){
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern,cName))
		{
			return true;
		}
		else{
			throw new PurchaseException("Invalid Empl Name Should start "
					+ "with capital"+"Only characters allowed");
		}}
		else
		{
			throw new PurchaseException("Name should have less than 20 characters");
		}
		
	}

	@Override
	public boolean validateMailid(String cMail) throws PurchaseException {
		// TODO Auto-generated method stub
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";
                 
        Pattern pat = Pattern.compile(emailRegex);
      if(pat.matcher(cMail).matches())
      {
    	  return true;
      }
      else
      {
    	  throw new PurchaseException("Enter valid email id");
      }
	}

	@Override
	public boolean validateCphonenumber(String cPhone) throws PurchaseException {
		// TODO Auto-generated method stub
		if (cPhone.length()==10){
			String phonePattern="[0-9]+";
			if(Pattern.matches(phonePattern,cPhone))
			{
				return true;
			}
			else{
				throw new PurchaseException("Invalid Phone number should contain only digits");
			}}
			else
			{
				throw new PurchaseException("Number should have 10 degits");
			}
	}



	@Override
	public String validateDate() throws PurchaseException {
		// TODO Auto-generated method stub
		LocalDate currentdate=LocalDate.now();
		String date2=currentdate.toString();
		
		
		
			return date2;
		
		
	}

	@Override
	public boolean validateMobileid(int mId) throws PurchaseException {
		// TODO Auto-generated method stub
		ArrayList<Mobile>allMobs=custDao.getAllMobile();
		Integer i=mId;
		if(i.SIZE==4){
		if(allMobs!=null){
			for(Mobile mob:allMobs)
			{
				if(mob.getmId() == mId)
				return true;
				}
			}
				else
					throw new PurchaseException("Invalid mobile id");
					
	}
	else
		throw new PurchaseException("Invalid mobile id");
		
	return false;
	}

	@Override
	public ArrayList<Mobile> searchMob(int minPrice, int maxPrice)
			throws PurchaseException {
		
		return custDao.searchMob(minPrice,maxPrice);
		
	}

	@Override
	public ArrayList<Mobile> getAllMobile() throws PurchaseException {
		// TODO Auto-generated method stub
		return custDao.getAllMobile();
	}
}

	
