package com.capgemini.client;

import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.BookingException;
import com.capgemini.service.*;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.PurchaseException;


public class MainClient {
	static TrainService trainService=null;
	public static void main (String args[]){
	Scanner sc=new Scanner(System.in);
	while(true)
	{
		System.out.println("What do you want to do?");
		System.out.println(" 1:Book ticket \n "
				
				+ " 2:Exit");
		System.out.println("Enter ur choice");
		int choice=0;
		trainService=new TrainServiceImpl1();
		choice=sc.nextInt();
		switch(choice)
		{
		case 1:bookticket(); break;
		case 2:System.exit(0);
default:System.out.println("Invalid input");

		
		}
	}
}
	private static void bookticket() {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		ArrayList<TrainBean> trainList;
		
		try {
			trainList = trainService.TrainDetails();;
		
		System.out.println("\tTrainid  \t traintype \t dateofjourney \tfromstop \ttostop \tavailableseats \t fare");
		for(TrainBean mm:trainList)
		{
			System.out.println("\t"+mm.getTrainId()+"\t"+mm.getTrainType()+"\t"+mm.getDateOfJourney()+"\t"+mm.getFromStop()+"\t"+mm.getToStop()+"\t"+mm.getAvailableSeats()+"\t"+mm.getFare());
		}
		} catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Enter custumer id");
		String custumerid=sc.next();
		System.out.println("Enter train id");
		int trainid=sc.nextInt();
		System.out.println("Enter number of seats");
		int no=sc.nextInt();
	
		
		
		
		
		
	}
}