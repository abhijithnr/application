package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.capgemini.bean.*;
import com.capgemini.exception.*;
import com.capgemini.util.*;




public class TrainDaoImpl implements TrainDao{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	ArrayList<TrainBean> trainList=null;

	@Override
	public ArrayList<TrainBean> retrieveTrainDetails()  {
		// TODO Auto-generated method stub
	ArrayList<TrainBean> trainList=new ArrayList<TrainBean>();
		try
		{
			
			con=DBUtil.getConn();
			String selectqry="SELECT * FROM TrainDetails";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next())
			{
				trainList.add(new TrainBean(rs.getInt("trainId"),rs.getString("trainType"),rs.getDate(7).toLocalDate(),rs.getString("fromStop"),rs.getString("toStop"),rs.getInt("availableSeats"),rs.getInt("fare")));
			
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			try {
				throw new BookingException(e.getMessage());
			} catch (BookingException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		finally
		{
		try {
			st.close();
			rs.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		return trainList;
		
	}

	@Override
	public int bookTicket(BookingBean bookingbean) {
		// TODO Auto-generated method stub

		int data=0;
		try {
			con=DBUtil.getConn();
			String insertQry="INSERT INTO BOOKINGDETAILS(bookingid,custId,trainId,noOfSeats) VALUES(booking_Id_seq_5.nextval,?,?,?)";
			pst=con.prepareStatement(insertQry);
			/*pst.setInt(1, cs.getcPid());*/
			pst.setString(1, bookingbean.getCustId());
			pst.setInt(2, bookingbean.getTrainId());
			pst.setInt(3, bookingbean.getNoOfSeat());;
			data=pst.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				throw new BookingException(e.getMessage());
			} catch (BookingException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} 
		
		return data;

	}

}
