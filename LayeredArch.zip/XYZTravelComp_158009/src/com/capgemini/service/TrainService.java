package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.*;

public interface TrainService {
	
	public ArrayList<TrainBean> retrieveTrainDetails();
	ArrayList<BookingBean> BookTicket(BookingBean bookingBean)throws BookingException;
	ArrayList<TrainBean> TrainDetails();

}
