package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.BookingException;
import com.capgemini.bean.*;
import com.capgemini.dao.*;


public class TrainServiceImpl1 implements TrainService{
	TrainDao trainDao1=null;
	public TrainServiceImpl1()
	{
		trainDao1=new TrainDaoImpl();
	}

	
	

	@Override
	public int BookTicket(BookingBean bookingBean)  {
		// TODO Auto-generated method stub
		return trainDao1.bookTicket(bookingBean);
	}




	@Override
	public ArrayList<TrainBean> TrainDetails() {
		// TODO Auto-generated method stub
		return trainDao1.retrieveTrainDetails();
		
	}




	@Override
	public ArrayList<TrainBean> retrieveTrainDetails() {
		// TODO Auto-generated method stub
		return null;
	}

}
